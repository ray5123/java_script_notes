import { formatPrice, getElement } from '../utils.js';

const addToCartDOM = (product) => {
  console.log(product);
};

export default addToCartDOM;
