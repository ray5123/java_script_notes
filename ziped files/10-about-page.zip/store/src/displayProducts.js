import { formatPrice } from './utils.js';
import { addToCart } from './cart/setupCart.js';
const display = () => {};

export default display;
