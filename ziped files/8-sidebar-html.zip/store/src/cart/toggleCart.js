import { getElement } from '../utils.js';

export const openCart = () => {};
